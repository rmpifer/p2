insert into test_tbl(id, name) values (1, 'Jane'), (2, 'John')
